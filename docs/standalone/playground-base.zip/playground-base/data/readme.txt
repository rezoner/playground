Put your JSON data here with .json extension
Put your TEXT data here with any extension

  app.loadData("something");

this will look for something.json

  var value = app.data.something;

this is how you access data after its loaded
