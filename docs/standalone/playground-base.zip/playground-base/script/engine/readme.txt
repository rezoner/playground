Put whatever is reusable and falls into ENGINE.MyThing namespace

Of course if you don't like ENGINE namespace, you are free to change it.
It's not a part of ecosystem.
