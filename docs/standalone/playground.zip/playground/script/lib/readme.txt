This is where external libraries go. 
This folder doesn't obey naming conventions
The files are named as provided by their authors
